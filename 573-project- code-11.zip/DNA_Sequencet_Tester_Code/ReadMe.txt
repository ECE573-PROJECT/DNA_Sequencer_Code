'''
The code is based on the a class project at Rutgers University.

Project Title : DNA Sequencer Detector
Class : Data Structures and Algorithms
Course No : ECE573
Professor : Jha
Semester : Spring 2018

Group Participants : Divyaprakash Dhurandhar, Tina Drew, Anirudh Kulkarni, and Juhi Tripathi

This code creates files with randon characters to simulate a randomly generate DNA sequence
'''

The folder is broken in to two sets:

ALPHA TEST CODE:
Contains the code and files to run the final tests

BETA TEST CODE:
Contains the code and files to run the intital tests

--> Dataset
    Contains tests files used to run the sequences. 
    This files must be stored in the same directory as the code files. 